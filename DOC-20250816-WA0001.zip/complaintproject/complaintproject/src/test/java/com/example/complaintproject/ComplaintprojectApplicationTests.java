package com.example.complaintproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComplaintprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
