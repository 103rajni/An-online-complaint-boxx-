package com.example.complaintproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComplaintprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComplaintprojectApplication.class, args);
	}

}
